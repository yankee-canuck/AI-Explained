import { prisma } from "@/lib/prisma";

export async function POST(req: Request) {
  const { email, amount = 10 } = await req.json();
  if (!email) return new Response("Missing email", { status: 400 });
  await prisma.user.upsert({
    where: { email },
    update: { xpTotal: { increment: amount } },
    create: { email, xpTotal: amount },
  });
  return Response.json({ ok: true });
}
