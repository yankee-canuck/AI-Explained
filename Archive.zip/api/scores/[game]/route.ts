import { NextResponse } from "next/server";
import { prisma } from "../../../../lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req: Request, { params }: { params: { game: string } }) {
  const { game } = params;
  const url = new URL(req.url);
  const rawTop = Number(url.searchParams.get("top"));
  const top = Math.max(1, Math.min(50, Number.isFinite(rawTop) ? rawTop : 10));

  const scores = await prisma.gameScore.findMany({
    where: { game },
    orderBy: [{ score: "desc" }, { createdAt: "asc" }],
    take: top,
    select: { id: true, name: true, score: true, timeMs: true, createdAt: true },
  });

  return NextResponse.json({ game, scores });
}

export async function POST(req: Request, { params }: { params: { game: string } }) {
  const { game } = params;
  const body = await req.json().catch(() => ({}));
  const { name, score, timeMs } = body as { name?: string; score?: number; timeMs?: number };

  if (!Number.isFinite(score)) {
    return NextResponse.json({ error: "Missing or invalid 'score'" }, { status: 400 });
  }

  const saved = await prisma.gameScore.create({
    data: {
      game,
      name: name?.slice(0, 24) ?? null,
      score: Math.round(score as number),
      timeMs: Number.isFinite(timeMs) ? Math.max(0, Math.round(timeMs as number)) : null,
    },
    select: { id: true, createdAt: true },
  });

  return NextResponse.json({ ok: true, id: saved.id, createdAt: saved.createdAt });
}
